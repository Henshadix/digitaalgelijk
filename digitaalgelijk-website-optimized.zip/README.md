﻿# Digitaalgelijk Website

## Installatie

1. Upload deze bestanden naar je server
2. Voer 
pm install uit om dependencies te installeren
3. Maak een .env.local bestand met de juiste instellingen (zie .env.local.example)
4. Bouw de applicatie met 
pm run build
5. Start de server met 
pm start

## Omgevingsvariabelen

Maak een .env.local bestand met de volgende variabelen:

- SMTP_HOST - SMTP server voor e-mails
- SMTP_PORT - SMTP poort (meestal 587)
- SMTP_USER - SMTP gebruikersnaam/e-mailadres
- SMTP_PASSWORD - SMTP wachtwoord
- SMTP_SECURE - Gebruik SMTP TLS (false voor poort 587)
- CONTACT_EMAIL - E-mailadres waar contactformulieren naartoe gaan
- NODE_ENV - Zet op 'production' voor productieomgeving
